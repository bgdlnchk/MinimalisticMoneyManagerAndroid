package com.bogdanlonchuk.minimalisticmoney.activities;

import android.content.Intent;
import android.support.annotation.NonNull;

import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.bogdanlonchuk.minimalisticmoney.R;
import com.bogdanlonchuk.minimalisticmoney.fragments.UserDashboardFragment;
import com.bogdanlonchuk.minimalisticmoney.fragments.UserExpenseFragment;
import com.bogdanlonchuk.minimalisticmoney.fragments.UserIncomeFragment;
import com.google.firebase.auth.FirebaseAuth;


public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private FrameLayout mFrameLayout;
    private UserDashboardFragment mDashboardFragmentUser;
    private UserIncomeFragment mUserIncomeFragment;
    private UserExpenseFragment mUserExpenseFragment;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Toolbar homeToolbar = findViewById(R.id.homeToolbar);
        homeToolbar.setTitle("Expense Manager");
        setSupportActionBar(homeToolbar);
        mAuth=FirebaseAuth.getInstance();

        mFrameLayout = findViewById(R.id.main_frame);
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(
                this,drawerLayout,homeToolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView drawerNavigationView = findViewById(R.id.drawerNavigationView);
        drawerNavigationView.setNavigationItemSelectedListener(this);

        mDashboardFragmentUser =new UserDashboardFragment();
        mUserIncomeFragment =new UserIncomeFragment();
        mUserExpenseFragment =new UserExpenseFragment();
        setCurrentFragment(mDashboardFragmentUser);
    }

    private void setCurrentFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_frame,fragment);
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
        DrawerLayout drawerLayout=findViewById(R.id.drawer_layout);
        if (drawerLayout.isDrawerOpen(GravityCompat.END)){
            drawerLayout.closeDrawer(GravityCompat.END);
        }else {

            Intent homeIntent = new Intent(Intent.ACTION_MAIN);
            homeIntent.addCategory( Intent.CATEGORY_HOME );
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(homeIntent);        }
    }

    public void showSelectedListener(int itemId){

        Fragment currentFragment = null;

        switch (itemId){
            case R.id.dashboard:
                currentFragment=new UserDashboardFragment();
                break;

            case R.id.income:
                currentFragment=new UserIncomeFragment();
                break;

            case R.id.expense:
                currentFragment=new UserExpenseFragment();
                break;

            case R.id.share:
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "Download this application from Google Play Store");
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
                break;

            case R.id.log_out:
                mAuth.signOut();
                Intent logOutIntent = new Intent(HomeActivity.this, MainActivity.class);
                startActivity(logOutIntent);
                break;
        }

        if (currentFragment!=null){
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.main_frame,currentFragment);
            fragmentTransaction.commit();
        }

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        showSelectedListener(item.getItemId());
        return true;
    }
}
